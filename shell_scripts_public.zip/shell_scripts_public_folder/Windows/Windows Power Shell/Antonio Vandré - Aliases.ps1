<#
Propriet�rio: Antonio Vandr� Pedrosa Furtunato Gomes.

Job: "mathematicalramblings.blogspot.com".

Script de aliases.

�ltima atualiza��o: 24-07-2021.
#>

New-Alias can 'Copiar anota��es p�blicas - LO - Docs.ps1';

New-Alias car 'Copiar artigos lidos - LO - Docs.ps1';

New-Alias cal 'Copiar atualmente lendo - LO - Docs.ps1';
