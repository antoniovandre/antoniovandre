# Projeto Mathematical Ramblings.

# Lan?ador do JavaAntonioVandreEval, vers?o ps1.

# ?ltima atualiza??o: 17-11-2023.

$temp = $pwd

Set-Location -Path F:\AntonioVandrePedrosaFurtunatoGomes\Java # Caminho para o diret?rio pessoal de aplica??es Java.

java -jar JavaAntonioVandreEval.jar  $args[0]

Set-Location -Path $temp
