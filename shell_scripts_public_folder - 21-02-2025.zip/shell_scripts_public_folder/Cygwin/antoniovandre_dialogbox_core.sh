#!/bin/bash.exe

# Proprietário: Antonio Vandré Pedrosa Furtunato Gomes (bit.ly/antoniovandre_legadoontologico).

# Caixa de diálogo, script core, para Cygwin.

# Última atualização: 21-09-2023.

echo "${@}"; read